
The files within this directory are necessary for compiling the
VSampleDemo application.

These files are downloaded from http://www.clootie.ru/delphi/download_dx92.html#Headers.
File Jedi.inc has been downloaded from http://www.delphi-jedi.org/ as part of the JCL.

All files seem to be released under the Mozilla Public License Version 1.1: 
(http://www.mozilla.org/MPL/MPL-1.1.html).

Therefore, I think it's OK to add them here for your convenience.

Listing of the files in this directory:

23.10.2006  02:00           239.320 Direct3D9.pas
23.10.2006  00:42           269.725 DirectDraw.pas
01.05.2007  02:18         1.383.503 DirectShow9.pas
01.05.2007  02:18           104.064 DirectSound.pas
18.04.2006  23:27             3.407 DirectX.inc
01.05.2007  02:18             6.507 DXTypes.pas
10.03.2008  00:54            49.311 Jedi.inc
